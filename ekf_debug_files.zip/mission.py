import numpy as np

from drone_gnc.simulation.integrators import (
    rk4_step,
)


def run_waypoint_mission(
    vehicle,
    controller,
    guidance,
    sensor_suite=None,
    ekf=None,
    duration=32.0,
    dt=0.01,
    gps_hz=10.0,
    wind=None,
):

    n = (
        int(
            round(
                duration / dt
            )
        )
        + 1
    )

    t = (
        np.arange(
            n,
            dtype=float,
        )
        * dt
    )

    # 12-state vehicle:
    #
    # [x y z
    #  u v w
    #  phi theta psi
    #  p q r]

    x = np.zeros(12)

    x[2] = 0.0

    controller.reset()

    if hasattr(
        guidance,
        "reset",
    ):
        guidance.reset(
            x[:3]
        )

    if ekf is not None:
        ekf.initialize(
            x[:3],
            x[3:6],
            x[6:9],
        )

    logs = {
        key: []
        for key in [
            "t",
            "state",
            "control",

            "ref",
            "vel_ref",
            "acc_ref",

            "att_ref",
            "rate_ref",

            "wp_index",
            "distance",
            "waypoints_reached",
            "mission_complete",

            "estimate",
            "gps_pos",
        ]
    }

    gps_period = max(
        1,
        int(
            round(
                1.0
                / (
                    gps_hz
                    * dt
                )
            )
        ),
    )

    gps_for_current_time = (
        np.full(
            3,
            np.nan,
        )
    )

    for k, tk in enumerate(t):

        # ---------------------------------------------
        # ESTIMATED STATE USED FOR FEEDBACK
        # ---------------------------------------------

        if ekf is None:

            feedback = x

        else:

            feedback = np.r_[
                ekf.p,
                ekf.v,

                x[6:9],
                x[9:12],
            ]

        # At t = 0, do not advance the reference yet.
        guidance_dt = (
            0.0
            if k == 0
            else dt
        )

        (
            pref,
            vref,
            yaw_ref,
            idx,
            dist,
        ) = guidance.update(
            feedback[:3],
            guidance_dt,
        )

        aref = np.asarray(
            getattr(
                guidance,
                "acc_ref",
                np.zeros(3),
            ),
            dtype=float,
        )

        # ---------------------------------------------
        # CONTROL
        # ---------------------------------------------

        (
            u,
            ctrl_info,
        ) = controller.command(
            feedback,
            pref,
            vref,
            yaw_ref,
            dt,
            acc_ref=aref,
        )

        # ---------------------------------------------
        # CURRENT ESTIMATED STATE
        # ---------------------------------------------

        if ekf is None:

            estimate = x.copy()

        else:

            estimate = np.r_[
                ekf.p,
                ekf.v,
                ekf.att,

                x[9:12],
            ]

        # ---------------------------------------------
        # LOG EVERYTHING AT THE SAME TIME
        # ---------------------------------------------

        logs["t"].append(
            tk
        )

        logs["state"].append(
            x.copy()
        )

        logs["control"].append(
            u.copy()
        )

        logs["ref"].append(
            pref.copy()
        )

        logs["vel_ref"].append(
            vref.copy()
        )

        logs["acc_ref"].append(
            aref.copy()
        )

        logs["att_ref"].append(
            ctrl_info[
                "att_ref"
            ].copy()
        )

        logs["rate_ref"].append(
            ctrl_info[
                "rate_ref"
            ].copy()
        )

        logs["wp_index"].append(
            idx
        )

        logs["distance"].append(
            dist
        )

        logs["waypoints_reached"].append(
            int(
                getattr(
                    guidance,
                    "reached_count",
                    idx,
                )
            )
        )

        logs["mission_complete"].append(
            bool(
                getattr(
                    guidance,
                    "complete",
                    False,
                )
            )
        )

        logs["estimate"].append(
            estimate
        )

        logs["gps_pos"].append(
            gps_for_current_time.copy()
        )

        # Last sample is logged but not propagated.
        if k == n - 1:
            break

        # ---------------------------------------------
        # PROPAGATE TRUE VEHICLE
        # ---------------------------------------------

        xdot_nominal = (
            vehicle.derivatives(
                x,
                u,
            )
        )

        acc_i = (
            xdot_nominal[
                3:6
            ].copy()
        )

        if wind is None:

            x = rk4_step(
                lambda xx, uu:
                    vehicle.derivatives(
                        xx,
                        uu,
                    ),
                x,
                u,
                dt,
            )

        else:

            wind_acc = np.asarray(
                wind.acceleration(),
                dtype=float,
            )

            def dynamics_with_wind(
                xx,
                uu,
            ):
                dx = (
                    vehicle.derivatives(
                        xx,
                        uu,
                    ).copy()
                )

                dx[3:6] += (
                    wind_acc
                )

                return dx

            x = rk4_step(
                dynamics_with_wind,
                x,
                u,
                dt,
            )

            acc_i = (
                acc_i
                + wind_acc
            )

        # ---------------------------------------------
        # SENSOR / EKF PROPAGATION
        # ---------------------------------------------

        gps_for_current_time = (
            np.full(
                3,
                np.nan,
            )
        )

        if (
            sensor_suite is not None
            and ekf is not None
        ):

            (
                accel_m,
                gyro_m,
            ) = sensor_suite.imu(
                x,
                acc_i,
                dt,
            )

            ekf.predict(
                accel_m,
                gyro_m,
            )

            if (
                (k + 1)
                % gps_period
                == 0
            ):

                (
                    gps_p,
                    gps_v,
                ) = sensor_suite.gps(
                    x
                )

                ekf.update_gps(
                    gps_p,
                    gps_v,
                )

                gps_for_current_time = (
                    gps_p.copy()
                )

    for key in logs:
        logs[key] = np.asarray(
            logs[key]
        )

    return logs